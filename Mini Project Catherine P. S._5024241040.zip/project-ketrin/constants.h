#pragma once

int const screen_width  { 640 };
int const screen_height { 480 };

double const fps { 60.0 };
